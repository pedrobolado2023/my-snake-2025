// Configurações do Jogo
const CONFIG = {
    // Arena
    ARENA_SIZE: 5000,
    ARENA_SHAPE: 'circle', // 'circle' ou 'square'
    ARENA_BORDER_WIDTH: 20,
    
    // Snake
    SNAKE_INITIAL_LENGTH: 10,
    SNAKE_SEGMENT_SIZE: 10,
    SNAKE_SEGMENT_SPACING: 8,
    SNAKE_BASE_SPEED: 180,
    SNAKE_BOOST_MULTIPLIER: 2,
    SNAKE_BOOST_COST_PER_SECOND: 0.5,
    SNAKE_MIN_LENGTH_TO_BOOST: 15,
    SNAKE_TURN_SPEED: 0.08,
    
    // Food
    FOOD_SIZE: 8,
    FOOD_VALUE: 1,
    FOOD_SPAWN_RATE: 5, // por segundo
    FOOD_MIN_COUNT: 200,
    FOOD_DESPAWN_TIME: 30000, // ms
    
    // Food Especial
    FOOD_GIANT_SIZE: 24,
    FOOD_GIANT_VALUE: 10,
    FOOD_GIANT_SPAWN_INTERVAL: 30000, // ms
    FOOD_GIANT_COLOR: '#FFD700',
    
    // Partículas
    PARTICLE_LIFETIME: 1000, // ms
    PARTICLE_COUNT_ON_DEATH: 20,
    PARTICLE_COUNT_ON_EAT: 5,
    
    // Câmera
    CAMERA_LERP_FACTOR: 0.1,
    ZOOM_MIN: 0.5,
    ZOOM_MAX: 1.2,
    ZOOM_FACTOR: 0.0003,
    
    // Renderização
    GRID_SIZE: 50,
    GRID_COLOR: 'rgba(26, 31, 58, 0.3)',
    BACKGROUND_COLOR: '#0a0e27',
    
    // Cores Neon
    COLORS: {
        NEON_PINK: '#ff3366',
        NEON_CYAN: '#00ffcc',
        NEON_PURPLE: '#9d4edd',
        NEON_BLUE: '#00b4d8',
        NEON_GREEN: '#06ffa5',
        NEON_YELLOW: '#ffea00',
        NEON_ORANGE: '#ff6b35',
        BORDER: '#ff3366',
    },
    
    // Skins disponíveis
    SKINS: [
        { id: 'cyan', name: 'Cyan', colors: ['#00ffcc', '#00b4d8'] },
        { id: 'purple', name: 'Purple', colors: ['#9d4edd', '#c77dff'] },
        { id: 'pink', name: 'Pink', colors: ['#ff3366', '#ff6b9d'] },
        { id: 'green', name: 'Green', colors: ['#06ffa5', '#52b788'] },
        { id: 'yellow', name: 'Yellow', colors: ['#ffea00', '#ffd60a'] },
        { id: 'orange', name: 'Orange', colors: ['#ff6b35', '#ff9f1c'] },
        { id: 'blue', name: 'Blue', colors: ['#00b4d8', '#0077b6'] },
        { id: 'red', name: 'Red', colors: ['#e63946', '#f72585'] },
        { id: 'rainbow', name: 'Rainbow', colors: ['#ff3366', '#ffea00', '#06ffa5', '#00b4d8', '#9d4edd'] },
        { id: 'fire', name: 'Fire', colors: ['#ff0000', '#ff6b00', '#ffea00'] },
    ],
    
    // Performance
    TARGET_FPS: 60,
    MAX_DELTA_TIME: 100, // ms
};

// Exportar para uso global
if (typeof module !== 'undefined' && module.exports) {
    module.exports = CONFIG;
}
